﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace P209_ASP_Model.Models.ViewModels
{
    public class AuthorDetailsVM
    {
        public Author Author { get; set; }
        public IEnumerable<Book> Books { get; set; }
    }
}