﻿using P209_ASP_Model.Models;
using P209_ASP_Model.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace P209_ASP_Model.Controllers
{
    public class AuthorsController : Controller
    {
        // GET: Authors
        public ActionResult Details()
        {
            Author author = new Author
            {
                Id = 1,
                Firstname = "Samir",
                Lastname = "Dadash-zade",
                Image = null
            };
            Book book = new Book
            {
                Id = 1,
                Name = "Yeddi ogul isterem",
                Genre = "Aile-meiset",
                Image = null,
                ISBN = "1234567891"
            };
            Book book2 = new Book
            {
                Id = 2,
                Name = "Yeddi qiz isterem",
                Genre = "Aile-meiset",
                Image = null,
                ISBN = "1236567891"
            };

            var books = new List<Book> { book, book2 };

            var vm = new AuthorDetailsVM
            {
                Author = author,
                Books = books
            };

            return View(vm);
        }
    }
}