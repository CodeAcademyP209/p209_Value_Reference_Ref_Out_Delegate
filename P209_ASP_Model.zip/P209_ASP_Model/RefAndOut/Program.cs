﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefAndOut
{
    class Program
    {
        delegate bool NumberCheckers(int number);
        delegate bool NumberCheckersDec(decimal number);

        static void Main(string[] args)
        {
            int[] numbers = { 15, 25, 45 };

            SumArray(numbers, IsEven);
        }

        static int SumArray(int[] inputArray, NumberCheckersDec callbackFunc)
        {
            int total = 0;

            foreach (var number in inputArray)
            {
                if(callbackFunc(number))
                    total += number;
            }

            return total;
        }

        static bool IsEven(decimal n) => n % 2 == 0;

        #region ref and out
        //static void ChangeNumber(out int number)
        //{
        //    number = 10;
        //}
        #endregion
    }
}
